﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AsyncLoadExcelFiles
{
    public partial class AsyncExcel : Form
    {
        List<string> ExcelPathList = new List<string>();
        Dictionary<string, List<DataTable>> ExcelDataList = new Dictionary<string, List<DataTable>>();
        public AsyncExcel()
        {
            InitializeComponent();
        }

        private void btnOpenExcelFiles_Click(object sender, EventArgs e)
        {
            try
            {
                ExcelPathList = GetExcelPath().ToList<string>();
                if (ExcelPathList.Count() != 0)
                {
                    btnLoadExcelFilesData.Enabled = true;
                    cmbExcelFilesName.Enabled = true;
                    cmbSheetNames.Enabled = true;


                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private async void btnLoadExcelFilesData_Click(object sender, EventArgs e)
        {
            ExcelDataList.Clear();
            var ElapsedTime = System.Diagnostics.Stopwatch.StartNew();

            await Excel2Dict(ExcelPathList);
            ElapsedTime.Stop();
            var elapsedMs = ElapsedTime.ElapsedMilliseconds;
            MessageBox.Show(elapsedMs.ToString());
            
            LoadExcelNames2cmb();
        }
        private void LoadExcelNames2cmb()
        {
            cmbExcelFilesName.Items.Clear();
            cmbExcelFilesName.Items.AddRange(ExcelDataList.Keys.ToArray<string>());
        }
        private void cmbExcelFilesName_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbSheetNames.Items.Clear();
            cmbSheetNames.Text = "";
            ExcelDataList[cmbExcelFilesName.SelectedItem.ToString()].ForEach(ExcelSheet => cmbSheetNames.Items.Add(ExcelSheet.TableName.ToString()));

        }
        private void cmbSheetNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            grdSheetData.DataSource = ExcelDataList[cmbExcelFilesName.SelectedItem.ToString()].Find(Sheet => Sheet.TableName == cmbSheetNames.SelectedItem.ToString());

        }
        public string[] GetExcelPath()
        {
            using (OpenFileDialog OpenFile = new OpenFileDialog()
            {
                Filter = "Excel Files|*.xls;*.xlsx;*.xlsm"
               ,
                Multiselect = true
            })
            {
                if (OpenFile.ShowDialog() == DialogResult.OK)
                {
                    return OpenFile.FileNames;
                }
                return null;
            }

        }
        public async Task Excel2Dict(List<string> aExcelPathList)
        {
            
            foreach (string ExcelPath in aExcelPathList)
            {
                ExcelDataList.Add(GetFileName(ExcelPath), (await Task.Run(() => Excel2List(ExcelPath))));
            }

        }
        public string GetFileName(string aFilePath)
        {
            return (new System.IO.FileInfo(aFilePath)).Name.Split('.').FirstOrDefault();
        }
        public List<DataTable> Excel2List(string aPath)
        {
            List<DataRow> SheetsNameList = GetExcelSheetsName(aPath);
            List<DataTable> Drancy = new List<DataTable>();            
            foreach (DataRow Ligne in SheetsNameList)
            {
                Drancy.Add(LoadExcelSheet(aPath, Ligne["TABLE_NAME"].ToString().Trim('$')));
                Drancy.Last().TableName = Ligne["TABLE_NAME"].ToString().Trim('$');
            }

            return Drancy;
        }
        public DataTable LoadExcelSheet(string aExcelFilePath, string aSheetName)
        {
            using (OleDbConnection ExcelConnection = new OleDbConnection()
            {
                ConnectionString = $@"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = { aExcelFilePath };
            Extended Properties = 'Excel 12.0 Xml;HDR=YES;'",

            })
            {

                DataTable SheetData = new DataTable();
                OleDbCommand SQLCommand = new OleDbCommand($"Select * From [{aSheetName}$]", ExcelConnection);
                ExcelConnection.OpenAsync();
                ((OleDbDataAdapter)new OleDbDataAdapter(SQLCommand)).Fill(SheetData);
                ExcelConnection.Dispose();
                ExcelConnection.Close();
                return SheetData;
            }
        }
        public List<DataRow> GetExcelSheetsName(string aExcelPath)
        {
            using (OleDbConnection ExcelConnection = new OleDbConnection()
            { ConnectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source= {aExcelPath};
                                Extended Properties='Excel 12.0 Xml;HDR=YES;'" })
            {
                ExcelConnection.OpenAsync();
                List<DataRow> SheetsNameList = ExcelConnection.GetSchema("Tables").AsEnumerable().ToList<DataRow>();
                ExcelConnection.Dispose();
                ExcelConnection.Close();
                return SheetsNameList;

            }
        }

        
    }
}
