﻿
namespace AsyncLoadExcelFiles
{
    partial class AsyncExcel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOpenExcelFiles = new System.Windows.Forms.Button();
            this.btnLoadExcelFilesData = new System.Windows.Forms.Button();
            this.cmbExcelFilesName = new System.Windows.Forms.ComboBox();
            this.cmbSheetNames = new System.Windows.Forms.ComboBox();
            this.grdSheetData = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.grdSheetData)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOpenExcelFiles
            // 
            this.btnOpenExcelFiles.Location = new System.Drawing.Point(12, 27);
            this.btnOpenExcelFiles.Name = "btnOpenExcelFiles";
            this.btnOpenExcelFiles.Size = new System.Drawing.Size(75, 23);
            this.btnOpenExcelFiles.TabIndex = 0;
            this.btnOpenExcelFiles.Text = "Open";
            this.btnOpenExcelFiles.UseVisualStyleBackColor = true;
            this.btnOpenExcelFiles.Click += new System.EventHandler(this.btnOpenExcelFiles_Click);
            // 
            // btnLoadExcelFilesData
            // 
            this.btnLoadExcelFilesData.Enabled = false;
            this.btnLoadExcelFilesData.Location = new System.Drawing.Point(126, 28);
            this.btnLoadExcelFilesData.Name = "btnLoadExcelFilesData";
            this.btnLoadExcelFilesData.Size = new System.Drawing.Size(75, 23);
            this.btnLoadExcelFilesData.TabIndex = 1;
            this.btnLoadExcelFilesData.Text = "Async Load";
            this.btnLoadExcelFilesData.UseVisualStyleBackColor = true;
            this.btnLoadExcelFilesData.Click += new System.EventHandler(this.btnLoadExcelFilesData_Click);
            // 
            // cmbExcelFilesName
            // 
            this.cmbExcelFilesName.Enabled = false;
            this.cmbExcelFilesName.FormattingEnabled = true;
            this.cmbExcelFilesName.Location = new System.Drawing.Point(313, 28);
            this.cmbExcelFilesName.Name = "cmbExcelFilesName";
            this.cmbExcelFilesName.Size = new System.Drawing.Size(121, 21);
            this.cmbExcelFilesName.TabIndex = 2;
            this.cmbExcelFilesName.SelectedIndexChanged += new System.EventHandler(this.cmbExcelFilesName_SelectedIndexChanged);
            // 
            // cmbSheetNames
            // 
            this.cmbSheetNames.Enabled = false;
            this.cmbSheetNames.FormattingEnabled = true;
            this.cmbSheetNames.Location = new System.Drawing.Point(520, 28);
            this.cmbSheetNames.Name = "cmbSheetNames";
            this.cmbSheetNames.Size = new System.Drawing.Size(121, 21);
            this.cmbSheetNames.TabIndex = 3;
            this.cmbSheetNames.SelectedIndexChanged += new System.EventHandler(this.cmbSheetNames_SelectedIndexChanged);
            // 
            // grdSheetData
            // 
            this.grdSheetData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdSheetData.Location = new System.Drawing.Point(12, 73);
            this.grdSheetData.Name = "grdSheetData";
            this.grdSheetData.Size = new System.Drawing.Size(776, 365);
            this.grdSheetData.TabIndex = 4;
            // 
            // AsyncExcel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grdSheetData);
            this.Controls.Add(this.cmbSheetNames);
            this.Controls.Add(this.cmbExcelFilesName);
            this.Controls.Add(this.btnLoadExcelFilesData);
            this.Controls.Add(this.btnOpenExcelFiles);
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "AsyncExcel";
            this.Text = "Async Excel Files Loading";
            ((System.ComponentModel.ISupportInitialize)(this.grdSheetData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOpenExcelFiles;
        private System.Windows.Forms.Button btnLoadExcelFilesData;
        private System.Windows.Forms.ComboBox cmbExcelFilesName;
        private System.Windows.Forms.ComboBox cmbSheetNames;
        private System.Windows.Forms.DataGridView grdSheetData;
    }
}

