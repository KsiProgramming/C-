﻿namespace UIforexcel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpExcelMan = new System.Windows.Forms.GroupBox();
            this.lblSheet = new System.Windows.Forms.Label();
            this.cmbSheetList = new System.Windows.Forms.ComboBox();
            this.btnOpenExcelFile = new System.Windows.Forms.Button();
            this.gvwSheetData = new System.Windows.Forms.DataGridView();
            this.grpExcelMan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvwSheetData)).BeginInit();
            this.SuspendLayout();
            // 
            // grpExcelMan
            // 
            this.grpExcelMan.Controls.Add(this.lblSheet);
            this.grpExcelMan.Controls.Add(this.cmbSheetList);
            this.grpExcelMan.Controls.Add(this.btnOpenExcelFile);
            this.grpExcelMan.Location = new System.Drawing.Point(12, 3);
            this.grpExcelMan.Name = "grpExcelMan";
            this.grpExcelMan.Size = new System.Drawing.Size(761, 73);
            this.grpExcelMan.TabIndex = 0;
            this.grpExcelMan.TabStop = false;
            this.grpExcelMan.Text = "Excel Manipulation";
            // 
            // lblSheet
            // 
            this.lblSheet.AutoSize = true;
            this.lblSheet.Location = new System.Drawing.Point(249, 34);
            this.lblSheet.Name = "lblSheet";
            this.lblSheet.Size = new System.Drawing.Size(35, 13);
            this.lblSheet.TabIndex = 2;
            this.lblSheet.Text = "Sheet";
            // 
            // cmbSheetList
            // 
            this.cmbSheetList.FormattingEnabled = true;
            this.cmbSheetList.Location = new System.Drawing.Point(290, 29);
            this.cmbSheetList.Name = "cmbSheetList";
            this.cmbSheetList.Size = new System.Drawing.Size(121, 21);
            this.cmbSheetList.TabIndex = 1;
            this.cmbSheetList.SelectedIndexChanged += new System.EventHandler(this.cmbSheetList_SelectedIndexChanged);
            // 
            // btnOpenExcelFile
            // 
            this.btnOpenExcelFile.Location = new System.Drawing.Point(40, 29);
            this.btnOpenExcelFile.Name = "btnOpenExcelFile";
            this.btnOpenExcelFile.Size = new System.Drawing.Size(75, 23);
            this.btnOpenExcelFile.TabIndex = 0;
            this.btnOpenExcelFile.Text = "Open";
            this.btnOpenExcelFile.UseVisualStyleBackColor = true;
            this.btnOpenExcelFile.Click += new System.EventHandler(this.btnOpenExcelFile_Click);
            // 
            // gvwSheetData
            // 
            this.gvwSheetData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvwSheetData.Location = new System.Drawing.Point(12, 82);
            this.gvwSheetData.Name = "gvwSheetData";
            this.gvwSheetData.Size = new System.Drawing.Size(761, 356);
            this.gvwSheetData.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gvwSheetData);
            this.Controls.Add(this.grpExcelMan);
            this.Name = "Form1";
            this.Text = "Open Excel using OledB";
            this.grpExcelMan.ResumeLayout(false);
            this.grpExcelMan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvwSheetData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpExcelMan;
        private System.Windows.Forms.Label lblSheet;
        private System.Windows.Forms.ComboBox cmbSheetList;
        private System.Windows.Forms.Button btnOpenExcelFile;
        private System.Windows.Forms.DataGridView gvwSheetData;
    }
}

