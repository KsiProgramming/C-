﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UIforexcel
{
    public partial class Form1 : Form
    {
        public string ExcelPath;
        public List<DataTable> ExcelList;
        public Form1()
        {
            InitializeComponent();
            cmbSheetList.Enabled = false;
        }

        private void btnOpenExcelFile_Click(object sender, EventArgs e)
        {
            ExcelPath = GetExcelPath();
            ExcelList = Excel2List(ExcelPath);
            LoadSheetsNameTocmb();
            MessageBox.Show("Excel file is ready!");
            cmbSheetList.Enabled = true;

        }

        public void LoadSheetsNameTocmb()
        {
            //aSheetsName.ForEach(row => cmbSheetList.Items.Add(row["TABLE_NAME"].ToString().Trim('$')));
            ExcelList.ForEach(ExcelSheet => cmbSheetList.Items.Add(ExcelSheet.TableName));
        
        }

        private void cmbSheetList_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvwSheetData.DataSource = ExcelList.Find(Sheet => Sheet.TableName == cmbSheetList.SelectedItem.ToString());
        }
        public string GetExcelPath()
        {
            using (OpenFileDialog OpenFile = new OpenFileDialog() { Filter = "Excel Files|*.xls;*.xlsx;*.xlsm" })
            {
                if (OpenFile.ShowDialog() == DialogResult.OK)
                {
                    return OpenFile.FileName;
                }
                return null;
            }

        }
        public DataTable LoadExcelSheet(string aExcelFilePath, string aSheetName)
        {
            using (OleDbConnection ExcelConnection = new OleDbConnection()
            { ConnectionString = $@"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = { aExcelFilePath };
            Extended Properties = 'Excel 12.0 Xml;HDR=YES;'" })
            {
                DataTable SheetData = new DataTable();
                OleDbCommand SQLCommand = new OleDbCommand($"Select * From [{aSheetName}$]", ExcelConnection);
                ExcelConnection.Open();
                ((OleDbDataAdapter)new OleDbDataAdapter(SQLCommand)).Fill(SheetData);
                ExcelConnection.Close();
                return SheetData;
            }
        }

        public List<DataRow> GetExcelSheetsName(string aExcelPath)
        {
            using (OleDbConnection ExcelConnection = new OleDbConnection()
            { ConnectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source= {aExcelPath};
                                Extended Properties='Excel 12.0 Xml;HDR=YES;'" })
            {
                ExcelConnection.Open();
                List<DataRow> SheetsNameList = ExcelConnection.GetSchema("Tables").AsEnumerable().ToList<DataRow>();
                ExcelConnection.Close();
                return SheetsNameList;

            }
        }
        public  List<DataTable> Excel2List(string aPath)
        {
            List<DataTable> Table = new List<DataTable>();            
            List<DataRow> SheetsNameList = GetExcelSheetsName(aPath);
            foreach (DataRow row in SheetsNameList)
            {
                Table.Add(LoadExcelSheet(aPath, row["TABLE_NAME"].ToString().Trim('$')));
                Table.Last().TableName = row["TABLE_NAME"].ToString().Trim('$');

            }
            return Table;
        }



    }
}
